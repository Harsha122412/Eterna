import WebSocket from 'ws';
import { OrderStatus } from '../market/types';
import { sendOrderStatusUpdate } from './handlers';

const wss = new WebSocket.Server({ port: 8080 });

wss.on('connection', (ws) => {
    console.log('New client connected');

    ws.on('message', (message) => {
        console.log(`Received message: ${message}`);
        // Handle incoming messages if needed
    });

    ws.on('close', () => {
        console.log('Client disconnected');
    });
});

const broadcastOrderStatus = (orderId: string, status: OrderStatus) => {
    const message = JSON.stringify({ orderId, status });
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(message);
        }
    });
};

export { wss, broadcastOrderStatus };