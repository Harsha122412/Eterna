import { WebSocket } from 'ws';
import { OrderStatus } from '../market/types';

export const handleOrderStatusUpdate = (ws: WebSocket, orderId: string, status: OrderStatus) => {
    const message = JSON.stringify({
        type: 'orderStatusUpdate',
        orderId,
        status,
    });
    ws.send(message);
};

export const handleConnection = (ws: WebSocket) => {
    ws.on('message', (message: string) => {
        console.log(`Received message: ${message}`);
        // Handle incoming messages if needed
    });

    ws.on('close', () => {
        console.log('Client disconnected');
    });
};