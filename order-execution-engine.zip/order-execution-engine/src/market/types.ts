export interface Order {
    id: string;
    userId: string;
    amount: number;
    price: number;
    status: OrderStatus;
    createdAt: Date;
    updatedAt: Date;
}

export enum OrderStatus {
    PENDING = 'pending',
    ROUTING = 'routing',
    BUILDING = 'building',
    SUBMITTED = 'submitted',
    CONFIRMED = 'confirmed',
    FAILED = 'failed',
}

export interface OrderResponse {
    orderId: string;
    status: OrderStatus;
    message?: string;
}