import { Queue, Worker } from 'bullmq';
import { Order, OrderStatus, OrderResponse } from '../market/types';
import { Logger } from '../utils/logger';

export class Orders {
    private orderQueue: Queue<Order>;
    private activeOrders: Map<string, Order>;
    private logger: Logger;

    constructor() {
        this.orderQueue = new Queue<Order>('orderQueue');
        this.activeOrders = new Map<string, Order>();
        this.logger = new Logger();
        
        this.initializeWorker();
    }

    private initializeWorker() {
        const worker = new Worker<Order>('orderQueue', async (job) => {
            await this.processOrder(job.data);
        });

        worker.on('completed', (job) => {
            this.logger.log(`Order ${job.id} completed`);
            this.activeOrders.delete(job.id);
        });

        worker.on('failed', (job, err) => {
            this.logger.error(`Order ${job.id} failed: ${err.message}`);
            this.activeOrders.delete(job.id);
        });
    }

    public async addOrder(order: Order): Promise<OrderResponse> {
        this.activeOrders.set(order.id, order);
        await this.orderQueue.add(order.id, order);
        return { status: OrderStatus.Pending, orderId: order.id };
    }

    private async processOrder(order: Order) {
        // Logic to process the market order
        // This would involve interacting with the DEX router and executing the trade
        this.logger.log(`Processing order ${order.id}`);
        // Simulate order processing
        await new Promise(resolve => setTimeout(resolve, 2000));
        this.logger.log(`Order ${order.id} processed`);
    }

    public getActiveOrders(): Order[] {
        return Array.from(this.activeOrders.values());
    }
}