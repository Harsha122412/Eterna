import Fastify from 'fastify';
import { Server } from 'ws';
import { OrderExecutor } from './engine/orderExecutor';
import { DexRouter } from './engine/dexRouter';
import { createWebSocketServer } from './websocket/server';

const fastify = Fastify({ logger: true });
const orderExecutor = new OrderExecutor();
const dexRouter = new DexRouter();

// Set up routes for order execution
fastify.post('/execute-order', async (request, reply) => {
    const order = request.body;
    try {
        const result = await orderExecutor.processOrder(order);
        reply.send(result);
    } catch (error) {
        reply.status(500).send({ error: error.message });
    }
});

// Start the Fastify server
const start = async () => {
    try {
        await fastify.listen(3000);
        console.log('Server listening on http://localhost:3000');
        createWebSocketServer(fastify.server);
    } catch (err) {
        fastify.log.error(err);
        process.exit(1);
    }
};

start();