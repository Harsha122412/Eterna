export interface Order {
    id: string;
    type: 'market' | 'limit';
    amount: number;
    price?: number;
    status: OrderStatus;
}

export interface OrderStatus {
    id: string;
    status: 'pending' | 'routing' | 'building' | 'submitted' | 'confirmed' | 'failed';
    timestamp: Date;
}

export interface OrderResponse {
    orderId: string;
    status: OrderStatus;
    message?: string;
}