import axios from 'axios';

export class DexRouter {
    private raydiumUrl: string;
    private meteoraUrl: string;

    constructor() {
        this.raydiumUrl = 'https://api.raydium.io/v2/quote';
        this.meteoraUrl = 'https://api.meteora.xyz/v1/quote';
    }

    public async getBestQuote(tokenIn: string, tokenOut: string, amount: number): Promise<{ venue: string; price: number }> {
        const raydiumQuote = await this.fetchRaydiumQuote(tokenIn, tokenOut, amount);
        const meteoraQuote = await this.fetchMeteoraQuote(tokenIn, tokenOut, amount);

        return raydiumQuote.price < meteoraQuote.price ? 
            { venue: 'Raydium', price: raydiumQuote.price } : 
            { venue: 'Meteora', price: meteoraQuote.price };
    }

    private async fetchRaydiumQuote(tokenIn: string, tokenOut: string, amount: number): Promise<{ price: number }> {
        const response = await axios.get(`${this.raydiumUrl}?tokenIn=${tokenIn}&tokenOut=${tokenOut}&amount=${amount}`);
        return response.data;
    }

    private async fetchMeteoraQuote(tokenIn: string, tokenOut: string, amount: number): Promise<{ price: number }> {
        const response = await axios.get(`${this.meteoraUrl}?tokenIn=${tokenIn}&tokenOut=${tokenOut}&amount=${amount}`);
        return response.data;
    }
}