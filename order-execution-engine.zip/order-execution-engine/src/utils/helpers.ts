export function generateTransactionHash(orderId: string): string {
    const timestamp = Date.now().toString();
    return `${orderId}-${timestamp}`;
}

export function simulateNetworkDelay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
}