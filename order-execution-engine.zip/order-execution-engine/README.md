# Order Execution Engine

## Overview
The Order Execution Engine is a Node.js application designed to process market orders with decentralized exchange (DEX) routing. It utilizes WebSocket for real-time status updates, ensuring that users are informed about the state of their orders throughout the execution process.

## Features
- **Market Order Processing**: The engine is optimized for handling market orders, allowing users to execute trades quickly and efficiently.
- **DEX Routing**: Integrates with multiple DEXs, including Raydium and Meteora, to fetch quotes and select the best execution venue.
- **WebSocket Updates**: Provides live updates on order status, including pending, routing, building, submitted, confirmed, and failed statuses.
- **Order Management**: Utilizes BullMQ for managing an order queue and implements retry logic for failed orders.

## Setup
1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd order-execution-engine
   ```

2. **Install Dependencies**
   ```bash
   npm install
   ```

3. **Run the Application**
   ```bash
   npm start
   ```

## Usage
Once the server is running, you can send market orders to the designated endpoint. The engine will process the orders and provide real-time updates via WebSocket.

## Extending the Engine
The current implementation focuses on market orders, but the architecture allows for easy extension to support:
- **Limit Orders**: Implement logic to handle limit price conditions.
- **Sniper Orders**: Add functionality for executing trades at specific price points within a defined timeframe.

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License.